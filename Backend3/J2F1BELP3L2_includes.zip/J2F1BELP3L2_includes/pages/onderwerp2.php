<!-- jouw HTML met de inhoud over onderwerp 2 komt hier... -->
<?php
	$title = "Onderwerp 2";
	$description = "Dit is de beschrijving van Onderwerp 2. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis eget ullamcorper ligula. Phasellus tincidunt ligula in facilisis consectetur. Sed hendrerit ante eu semper dapibus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Quisque posuere nisl non eros luctus, vitae iaculis nisl efficitur. Nulla bibendum diam eu lacus gravida, ut consectetur purus interdum. In quis nunc ut orci egestas iaculis. Nulla dapibus sagittis elit at aliquet. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Phasellus pellentesque, nisl et mattis consectetur, nulla lectus aliquam elit, eget sagittis arcu mauris eget ex.";
	$image = "images/pdo.png";
?>

<h1><?php echo $title; ?></h1>
<p><?php echo $description; ?></p>
<img src=<?php echo $image; ?>