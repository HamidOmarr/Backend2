<!-- jouw HTML voor een Header komt hier... 
Gebruik hier tenminste een header afbeelding en een menu
Zorg dat je in het menu bij elk item een url parameter zet
om te bepalen welke inhoud er ingeladen moet worden in je html
-->

<header>
	<img src="images/pdo.png">

	<nav>
		<ul>
			<li><a href="index.php?content=onderwerp1">Onderwerp 1</a></li>
			<li><a href="index.php?content=onderwerp2">Onderwerp 2</a></li>
			<li><a href="index.php?content=onderwerp3">Onderwerp 3</a></li>
		</ul>
	</nav>
</header>
