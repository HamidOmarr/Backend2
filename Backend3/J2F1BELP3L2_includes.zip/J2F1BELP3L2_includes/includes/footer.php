<!-- jouw HTML voor een Footer komt hier... -->
<!-- Benoem hier ten minste je naam en de tijd -->

<footer>
	<p>Gemaakt door Hamid</p>
	<p><?php echo "Huidige tijd: " . date("H:i:s"); ?></p>
</footer>
