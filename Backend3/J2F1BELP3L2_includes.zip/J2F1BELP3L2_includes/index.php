<!doctype html>
<head>
  <title>Includes en require</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

	<?php
		include 'includes/header.php';
	?>
	
<?php
$content = isset($_GET['content']) ? $_GET['content'] : 'onderwerp1';

switch ($content) {
		case 'onderwerp1':
			include 'pages/onderwerp1.php';
			break;
		case 'onderwerp2':
			include 'pages/onderwerp2.php';
			break;
		case 'onderwerp3':
			include 'pages/onderwerp3.php';
			break;
		default:
			echo 'Ongeldige content';
			break;
	}
?>

	<?php
		include 'includes/footer.php';
	?>

</body>
</html>
